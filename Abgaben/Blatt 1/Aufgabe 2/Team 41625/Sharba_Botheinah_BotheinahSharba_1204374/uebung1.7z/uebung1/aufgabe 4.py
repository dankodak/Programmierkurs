a=int(input("fakulitaete von a="))
x=1
if a==0:
  x=1
else:
  while (a > 1):
      x = a * x
      a = a - 1
print(x)


