import cmath
a=float(input ("a="))
b=float(input ("b="))
c=float(input ("c="))
if a==0:
    print("please inter a number other than 0")
    a = float(input("a="))
d=cmath.sqrt(b*b-4*a*b)
x1=(-b-d)/(2*a)
x2=(-b+d)/(2*a)
print ('x1=',x1,'x2=',x2)

