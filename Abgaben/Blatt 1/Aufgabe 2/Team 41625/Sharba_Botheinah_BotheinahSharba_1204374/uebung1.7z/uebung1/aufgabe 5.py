import math
a=int(input("number of werts:"))
for x in range(0, a):
    import random
    b=random.uniform(-0.5, 0.5)
    print("{:2f} | {:3f} | {:.4f}".format(b, math.sin(b), b-(math.sin(b))))